WONDERWORLD GUEST APP — DELUXE MOBILE SAMPLE

This is the Android sample version of the Deluxe desktop concept.
It includes the Aero/Frutiger interface, startup splash, attraction cards,
ticket wallet, tear-off ticket interactions, Season Pass and confetti.

GITHUB PHONE BUILD:
1. Upload wonderworld_android_app_deluxe_source.zip to your repository.
2. Create .github/workflows/build-apk.yml using the workflow included in this project.
3. Open Actions and run “Build WonderWorld Deluxe APK”.
4. Download the WonderWorld-Guest-App-Deluxe-APK artifact.

This is a prototype. Checkout buttons and real purchase verification are not connected.
