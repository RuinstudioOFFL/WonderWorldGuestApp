@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo   WonderWorld Guest App - Android APK Builder
echo ===============================================
echo.
where adb >nul 2>nul
if not exist "%LOCALAPPDATA%\Android\Sdk" (
  echo Android SDK was not found in the normal location.
  echo Install Android Studio, open this folder once, and let it install SDK 35.
  echo Then run this BAT again.
  pause
  exit /b 1
)
set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not exist gradlew.bat (
  echo Gradle wrapper is missing. Open the project in Android Studio and select:
  echo File ^> Sync Project with Gradle Files
  echo Then use Build ^> Build APK(s).
  pause
  exit /b 1
)
call gradlew.bat clean assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Read the error above.
  pause
  exit /b 1
)
echo.
echo BUILD COMPLETE.
echo APK location:
echo app\build\outputs\apk\debug\app-debug.apk
explorer "app\build\outputs\apk\debug"
pause
