WonderWorld Mobile Deluxe sample

Includes startup animation, synthesized sounds, ticket wallet persistence, drag/tap ticket ripping, Season Pass confetti, interactive map, news, and settings.

Upload the ZIP and use the included GitHub Actions workflow.
