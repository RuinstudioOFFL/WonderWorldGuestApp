WONDERWORLD GUEST APP — ANDROID PROJECT

This is the Android/APK version of the WonderWorld Guest App.

EASIEST BUILD METHOD
1. Install Android Studio.
2. Open this entire folder in Android Studio.
3. Allow Gradle and Android SDK components to download.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK will appear at:
   app\build\outputs\apk\debug\app-debug.apk

IMPORTANT
- A debug APK can be installed manually for testing.
- A public release should use a signed release APK or Android App Bundle.
- Android may ask permission to install unknown apps when sideloading.
- The app bundles the interface locally and does not need a browser.
